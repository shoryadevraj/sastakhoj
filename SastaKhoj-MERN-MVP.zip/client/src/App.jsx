import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import SearchResults from "./pages/SearchResults";
import ProductDetails from "./pages/ProductDetails";
import ShopkeeperDashboard from "./pages/ShopkeeperDashboard";

export default function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/search" element={<SearchResults />} />
        <Route path="/product/:id" element={<ProductDetails />} />
        <Route
          path="/shopkeeper"
          element={
            <ProtectedRoute roles={["shopkeeper"]}>
              <ShopkeeperDashboard />
            </ProtectedRoute>
          }
        />
      </Routes>
      <footer className="footer">
        <div className="container footer-inner">
          <span>© {new Date().getFullYear()} SastaKhoj</span>
          <span>Compare Local Prices, Shop Smarter.</span>
        </div>
      </footer>
    </BrowserRouter>
  );
}
