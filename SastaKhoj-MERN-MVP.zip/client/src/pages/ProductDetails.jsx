import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import api from "../services/api";
import PriceCard from "../components/PriceCard";

export default function ProductDetails() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get(`/products/${id}`),
      api.get(`/listings/compare/${id}`)
    ]).then(([productRes, listingRes]) => {
      setProduct(productRes.data.product);
      setListings(listingRes.data.listings);
    }).finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="page-center">Loading...</div>;
  if (!product) return <div className="page-center">Product not found.</div>;

  return (
    <main className="container page">
      <Link to="/search" className="back-link">← Back</Link>
      <section className="product-detail">
        <div className="detail-image">{product.image ? <img src={product.image} alt={product.name} /> : "🛍️"}</div>
        <div>
          <div className="eyebrow">{product.category || "PRODUCT"}</div>
          <h1>{product.name}</h1>
          <p>{product.brand} {product.unit && `• ${product.unit}`}</p>
          <p>{product.description || "Compare local prices for this product."}</p>
        </div>
      </section>

      <div className="comparison-heading">
        <div>
          <div className="eyebrow">LOCAL PRICE COMPARISON</div>
          <h2>{listings.length} shop{listings.length === 1 ? "" : "s"} found</h2>
        </div>
      </div>

      {listings.length === 0 ? (
        <div className="empty"><h2>No local listings yet</h2><p>Ask a nearby shopkeeper to list this product.</p></div>
      ) : (
        <div className="price-list">
          {listings.map((listing, index) => <PriceCard key={listing._id} listing={listing} index={index} />)}
        </div>
      )}
    </main>
  );
}
