import { useEffect, useState } from "react";
import { useSearchParams, Link } from "react-router-dom";
import api from "../services/api";
import ProductCard from "../components/ProductCard";

export default function SearchResults() {
  const [params] = useSearchParams();
  const q = params.get("q") || "";
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api.get(`/products?q=${encodeURIComponent(q)}`)
      .then(res => setProducts(res.data.products))
      .finally(() => setLoading(false));
  }, [q]);

  return (
    <main className="container page">
      <div className="page-title">
        <div className="eyebrow">SEARCH RESULTS</div>
        <h1>Results for “{q}”</h1>
      </div>

      {loading ? <p>Searching...</p> : products.length === 0 ? (
        <div className="empty">
          <h2>No products found</h2>
          <p>Try another product name, brand or category.</p>
          <Link to="/" className="primary-button inline-button">Back to search</Link>
        </div>
      ) : (
        <div className="product-grid">
          {products.map(product => <ProductCard key={product._id} product={product} />)}
        </div>
      )}
    </main>
  );
}
