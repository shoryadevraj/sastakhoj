import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../services/api";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const { saveSession } = useAuth();
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const { data } = await api.post("/auth/login", form);
      saveSession(data);
      navigate(data.user.role === "shopkeeper" ? "/shopkeeper" : "/");
    } catch (err) {
      setError(err.response?.data?.message || "Login failed");
    }
  };

  return (
    <main className="auth-page">
      <form className="auth-card" onSubmit={submit}>
        <img src="/logo.png" className="auth-logo" alt="SastaKhoj" />
        <h1>Welcome back</h1>
        <p>Sign in to continue to SastaKhoj.</p>
        {error && <div className="error">{error}</div>}
        <label>Email<input type="email" required value={form.email} onChange={e => setForm({...form, email:e.target.value})} /></label>
        <label>Password<input type="password" required value={form.password} onChange={e => setForm({...form, password:e.target.value})} /></label>
        <button className="primary-button">Login</button>
        <div className="auth-footer">New here? <Link to="/register">Create an account</Link></div>
      </form>
    </main>
  );
}
