import { useEffect, useState } from "react";
import api from "../services/api";

const emptyShop = {
  name: "", phone: "", address: { street:"", city:"", state:"", pincode:"" },
  latitude: "", longitude: ""
};

export default function ShopkeeperDashboard() {
  const [shop, setShop] = useState(null);
  const [listings, setListings] = useState([]);
  const [products, setProducts] = useState([]);
  const [shopForm, setShopForm] = useState(emptyShop);
  const [listingForm, setListingForm] = useState({ productId:"", price:"", stockAvailable:true, quantity:0 });
  const [message, setMessage] = useState("");

  const load = async () => {
    const [shopRes, listingRes, productsRes] = await Promise.all([
      api.get("/shops/me/current"),
      api.get("/listings/mine"),
      api.get("/products")
    ]);
    setShop(shopRes.data.shop);
    setListings(listingRes.data.listings);
    setProducts(productsRes.data.products);

    if (shopRes.data.shop) {
      const s = shopRes.data.shop;
      setShopForm({
        name:s.name || "",
        phone:s.phone || "",
        address:s.address || emptyShop.address,
        latitude:s.location?.coordinates?.[1] || "",
        longitude:s.location?.coordinates?.[0] || ""
      });
    }
  };

  useEffect(() => { load().catch(console.error); }, []);

  const saveShop = async (e) => {
    e.preventDefault();
    const { data } = await api.post("/shops", shopForm);
    setShop(data.shop);
    setMessage("Shop saved successfully.");
  };

  const addListing = async (e) => {
    e.preventDefault();
    await api.post("/listings", listingForm);
    setMessage("Product price saved.");
    setListingForm({ productId:"", price:"", stockAvailable:true, quantity:0 });
    load();
  };

  const deleteListing = async (id) => {
    await api.delete(`/listings/${id}`);
    load();
  };

  const updateAddress = (field, value) => {
    setShopForm({
      ...shopForm,
      address: { ...shopForm.address, [field]: value }
    });
  };

  return (
    <main className="container page">
      <div className="page-title">
        <div className="eyebrow">SHOPKEEPER</div>
        <h1>Manage your shop</h1>
        <p>Keep your local products and prices up to date.</p>
      </div>

      {message && <div className="success">{message}</div>}

      <div className="dashboard-grid">
        <section className="panel">
          <h2>{shop ? "Shop details" : "Create your shop"}</h2>
          <form onSubmit={saveShop} className="form-grid">
            <label>Shop name<input required value={shopForm.name} onChange={e=>setShopForm({...shopForm,name:e.target.value})}/></label>
            <label>Phone<input value={shopForm.phone} onChange={e=>setShopForm({...shopForm,phone:e.target.value})}/></label>
            <label>Street<input value={shopForm.address.street} onChange={e=>updateAddress("street",e.target.value)}/></label>
            <label>City<input value={shopForm.address.city} onChange={e=>updateAddress("city",e.target.value)}/></label>
            <label>State<input value={shopForm.address.state} onChange={e=>updateAddress("state",e.target.value)}/></label>
            <label>Pincode<input value={shopForm.address.pincode} onChange={e=>updateAddress("pincode",e.target.value)}/></label>
            <label>Latitude<input value={shopForm.latitude} onChange={e=>setShopForm({...shopForm,latitude:e.target.value})}/></label>
            <label>Longitude<input value={shopForm.longitude} onChange={e=>setShopForm({...shopForm,longitude:e.target.value})}/></label>
            <button className="primary-button">Save Shop</button>
          </form>
          <p className="hint">Location is optional for the first version. You can add coordinates later for nearby-shop search.</p>
        </section>

        <section className="panel">
          <h2>Add / update a price</h2>
          <form onSubmit={addListing} className="form-grid">
            <label>Product
              <select required value={listingForm.productId} onChange={e=>setListingForm({...listingForm,productId:e.target.value})}>
                <option value="">Select product</option>
                {products.map(p=><option key={p._id} value={p._id}>{p.name} {p.unit ? `(${p.unit})` : ""}</option>)}
              </select>
            </label>
            <label>Price (₹)<input type="number" min="0" step="0.01" required value={listingForm.price} onChange={e=>setListingForm({...listingForm,price:e.target.value})}/></label>
            <label>Quantity<input type="number" min="0" value={listingForm.quantity} onChange={e=>setListingForm({...listingForm,quantity:e.target.value})}/></label>
            <label className="checkbox"><input type="checkbox" checked={listingForm.stockAvailable} onChange={e=>setListingForm({...listingForm,stockAvailable:e.target.checked})}/> In stock</label>
            <button className="primary-button">Save Price</button>
          </form>
        </section>
      </div>

      <section className="panel">
        <h2>My listings</h2>
        {listings.length === 0 ? <p>No listings yet.</p> : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>Product</th><th>Price</th><th>Stock</th><th>Updated</th><th></th></tr></thead>
              <tbody>
                {listings.map(l => (
                  <tr key={l._id}>
                    <td>{l.product?.name}</td>
                    <td>₹{l.price}</td>
                    <td>{l.stockAvailable ? "Available" : "Out of stock"}</td>
                    <td>{new Date(l.updatedAt).toLocaleDateString()}</td>
                    <td><button className="danger-link" onClick={()=>deleteListing(l._id)}>Delete</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </main>
  );
}
