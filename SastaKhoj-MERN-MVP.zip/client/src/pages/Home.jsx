import { Link } from "react-router-dom";
import SearchBar from "../components/SearchBar";

export default function Home() {
  return (
    <main>
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow">LOCAL SHOPPING, MADE SMARTER</div>
          <h1>Find it locally.<br /><strong>Pay less.</strong></h1>
          <p>
            Search products, compare prices from nearby shops, and find the deal
            that works best for you.
          </p>
          <SearchBar />
          <div className="hero-links">
            <Link to="/register">Are you a shopkeeper? List your products →</Link>
          </div>
        </div>

        <div className="hero-card">
          <div className="mini-search">Parle-G 250g</div>
          <div className="deal-row">
            <div>
              <strong>₹18</strong>
              <span>Kumar General Store</span>
            </div>
            <b>BEST PRICE</b>
          </div>
          <div className="deal-row">
            <div>
              <strong>₹20</strong>
              <span>Sharma Store</span>
            </div>
            <small>0.4 km</small>
          </div>
          <div className="deal-row">
            <div>
              <strong>₹22</strong>
              <span>Gupta Mart</span>
            </div>
            <small>1.2 km</small>
          </div>
        </div>
      </section>

      <section className="container section">
        <div className="section-heading">
          <div>
            <div className="eyebrow">HOW IT WORKS</div>
            <h2>Simple for everyone.</h2>
          </div>
        </div>

        <div className="steps">
          <div className="step"><span>01</span><h3>Search</h3><p>Find the product you need.</p></div>
          <div className="step"><span>02</span><h3>Compare</h3><p>See prices from local shops.</p></div>
          <div className="step"><span>03</span><h3>Save</h3><p>Choose a better local deal.</p></div>
        </div>
      </section>
    </main>
  );
}
