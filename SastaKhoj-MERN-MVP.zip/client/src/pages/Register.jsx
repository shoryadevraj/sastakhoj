import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../services/api";
import { useAuth } from "../context/AuthContext";

export default function Register() {
  const [form, setForm] = useState({ name:"", email:"", password:"", phone:"", role:"customer" });
  const [error, setError] = useState("");
  const { saveSession } = useAuth();
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const { data } = await api.post("/auth/register", form);
      saveSession(data);
      navigate(data.user.role === "shopkeeper" ? "/shopkeeper" : "/");
    } catch (err) {
      setError(err.response?.data?.message || "Registration failed");
    }
  };

  return (
    <main className="auth-page">
      <form className="auth-card" onSubmit={submit}>
        <img src="/logo.png" className="auth-logo" alt="SastaKhoj" />
        <h1>Create account</h1>
        <p>Join SastaKhoj as a customer or local shopkeeper.</p>
        {error && <div className="error">{error}</div>}

        <label>Name<input required value={form.name} onChange={e => setForm({...form,name:e.target.value})} /></label>
        <label>Email<input type="email" required value={form.email} onChange={e => setForm({...form,email:e.target.value})} /></label>
        <label>Phone<input value={form.phone} onChange={e => setForm({...form,phone:e.target.value})} /></label>
        <label>Password<input type="password" minLength="6" required value={form.password} onChange={e => setForm({...form,password:e.target.value})} /></label>
        <label>Account type
          <select value={form.role} onChange={e => setForm({...form,role:e.target.value})}>
            <option value="customer">Customer</option>
            <option value="shopkeeper">Shopkeeper</option>
          </select>
        </label>
        <button className="primary-button">Create Account</button>
        <div className="auth-footer">Already registered? <Link to="/login">Login</Link></div>
      </form>
    </main>
  );
}
