import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <header className="navbar">
      <div className="nav-inner">
        <Link to="/" className="brand">
          <img src="/logo.png" alt="SastaKhoj" />
        </Link>

        <nav>
          <Link to="/">Home</Link>
          {user?.role === "shopkeeper" && <Link to="/shopkeeper">Dashboard</Link>}
          {!user ? (
            <>
              <Link to="/login">Login</Link>
              <Link to="/register" className="nav-button">Get Started</Link>
            </>
          ) : (
            <button className="link-button" onClick={handleLogout}>Logout</button>
          )}
        </nav>
      </div>
    </header>
  );
}
