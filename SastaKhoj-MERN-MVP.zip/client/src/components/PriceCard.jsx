export default function PriceCard({ listing, index }) {
  const shop = listing.shop;
  const address = shop?.address
    ? [shop.address.street, shop.address.city, shop.address.state].filter(Boolean).join(", ")
    : "Local shop";

  return (
    <div className={`price-card ${index === 0 ? "best-price" : ""}`}>
      <div>
        {index === 0 && <div className="best-badge">BEST PRICE</div>}
        <h3>{shop?.name || "Shop"}</h3>
        <p>{address}</p>
        <small>{listing.updatedAt ? `Updated ${new Date(listing.updatedAt).toLocaleDateString()}` : ""}</small>
      </div>
      <div className="price">₹{Number(listing.price).toFixed(2)}</div>
    </div>
  );
}
