import { Link } from "react-router-dom";

export default function ProductCard({ product }) {
  return (
    <Link className="product-card" to={`/product/${product._id}`}>
      <div className="product-image">
        {product.image ? <img src={product.image} alt={product.name} /> : "🛍️"}
      </div>
      <div>
        <h3>{product.name}</h3>
        <p>{[product.brand, product.unit].filter(Boolean).join(" • ")}</p>
        <span>{product.category || "Local product"}</span>
      </div>
    </Link>
  );
}
