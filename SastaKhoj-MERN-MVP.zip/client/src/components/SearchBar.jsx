import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function SearchBar({ initialValue = "" }) {
  const [query, setQuery] = useState(initialValue);
  const navigate = useNavigate();

  const submit = (e) => {
    e.preventDefault();
    const value = query.trim();
    if (value) navigate(`/search?q=${encodeURIComponent(value)}`);
  };

  return (
    <form className="search-box" onSubmit={submit}>
      <span>⌕</span>
      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search for a product..."
      />
      <button type="submit">Search</button>
    </form>
  );
}
