import { createContext, useContext, useEffect, useState } from "react";
import api from "../services/api";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const saveSession = (data) => {
    localStorage.setItem("sastakhoj_token", data.token);
    setUser(data.user);
  };

  const logout = () => {
    localStorage.removeItem("sastakhoj_token");
    setUser(null);
  };

  useEffect(() => {
    const token = localStorage.getItem("sastakhoj_token");
    if (!token) {
      setLoading(false);
      return;
    }

    api.get("/auth/me")
      .then(res => setUser(res.data.user))
      .catch(() => logout())
      .finally(() => setLoading(false));
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, saveSession, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
