# SastaKhoj

Local product price comparison platform built with the MERN stack.

## Features
- Customer registration/login
- Shopkeeper registration/login
- Shop creation and management
- Product search
- Local price listings
- Cheapest-price comparison
- Shopkeeper dashboard
- Admin-ready role system
- SastaKhoj branding/logo

## Requirements
- Node.js 20+
- MongoDB (local or MongoDB Atlas)

## Run backend
```bash
cd server
npm install
cp .env.example .env
npm run dev
```

## Run frontend
```bash
cd client
npm install
npm run dev
```

Frontend: http://localhost:5173
Backend: http://localhost:5000

The first version intentionally keeps payments, subscriptions, chatbot, realtime notifications and other non-core features out of the MVP.
