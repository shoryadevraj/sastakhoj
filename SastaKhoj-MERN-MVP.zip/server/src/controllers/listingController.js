import Listing from "../models/Listing.js";
import Shop from "../models/Shop.js";
import Product from "../models/Product.js";

export const createListing = async (req, res, next) => {
  try {
    const shop = await Shop.findOne({ owner: req.user._id });
    if (!shop) {
      return res.status(400).json({ success: false, message: "Create your shop first" });
    }

    const { productId, price, stockAvailable = true, quantity = 0 } = req.body;

    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found" });
    }

    const listing = await Listing.findOneAndUpdate(
      { product: productId, shop: shop._id },
      { price, stockAvailable, quantity },
      { new: true, upsert: true, setDefaultsOnInsert: true }
    ).populate("product").populate("shop");

    res.status(201).json({ success: true, listing });
  } catch (error) {
    next(error);
  }
};

export const getMyListings = async (req, res, next) => {
  try {
    const shop = await Shop.findOne({ owner: req.user._id });
    if (!shop) return res.json({ success: true, listings: [] });

    const listings = await Listing.find({ shop: shop._id })
      .populate("product")
      .populate("shop")
      .sort({ updatedAt: -1 });

    res.json({ success: true, listings });
  } catch (error) {
    next(error);
  }
};

export const comparePrices = async (req, res, next) => {
  try {
    const listings = await Listing.find({
      product: req.params.productId
    })
      .populate("product")
      .populate("shop")
      .sort({ price: 1 });

    const available = listings.filter(item => item.stockAvailable);

    res.json({
      success: true,
      listings: available
    });
  } catch (error) {
    next(error);
  }
};

export const updateListing = async (req, res, next) => {
  try {
    const shop = await Shop.findOne({ owner: req.user._id });
    if (!shop) return res.status(404).json({ success: false, message: "Shop not found" });

    const listing = await Listing.findOneAndUpdate(
      { _id: req.params.id, shop: shop._id },
      req.body,
      { new: true }
    ).populate("product").populate("shop");

    if (!listing) return res.status(404).json({ success: false, message: "Listing not found" });

    res.json({ success: true, listing });
  } catch (error) {
    next(error);
  }
};

export const deleteListing = async (req, res, next) => {
  try {
    const shop = await Shop.findOne({ owner: req.user._id });
    const listing = await Listing.findOneAndDelete({
      _id: req.params.id,
      shop: shop?._id
    });

    if (!listing) return res.status(404).json({ success: false, message: "Listing not found" });

    res.json({ success: true, message: "Listing deleted" });
  } catch (error) {
    next(error);
  }
};
