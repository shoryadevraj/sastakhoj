import Shop from "../models/Shop.js";

export const createOrUpdateShop = async (req, res, next) => {
  try {
    const { name, phone, address, latitude, longitude } = req.body;

    if (!name) {
      return res.status(400).json({ success: false, message: "Shop name is required" });
    }

    const update = {
      name,
      phone,
      address,
      ...(latitude !== undefined && longitude !== undefined
        ? { location: { type: "Point", coordinates: [Number(longitude), Number(latitude)] } }
        : {})
    };

    const shop = await Shop.findOneAndUpdate(
      { owner: req.user._id },
      update,
      { new: true, upsert: true, setDefaultsOnInsert: true }
    );

    res.status(200).json({ success: true, shop });
  } catch (error) {
    next(error);
  }
};

export const getMyShop = async (req, res, next) => {
  try {
    const shop = await Shop.findOne({ owner: req.user._id });
    res.json({ success: true, shop });
  } catch (error) {
    next(error);
  }
};

export const getShop = async (req, res, next) => {
  try {
    const shop = await Shop.findById(req.params.id).populate("owner", "name phone");
    if (!shop) return res.status(404).json({ success: false, message: "Shop not found" });
    res.json({ success: true, shop });
  } catch (error) {
    next(error);
  }
};

export const nearbyShops = async (req, res, next) => {
  try {
    const { lat, lng, radius = 5000 } = req.query;
    if (!lat || !lng) {
      return res.status(400).json({ success: false, message: "lat and lng are required" });
    }

    const shops = await Shop.find({
      location: {
        $near: {
          $geometry: {
            type: "Point",
            coordinates: [Number(lng), Number(lat)]
          },
          $maxDistance: Number(radius)
        }
      },
      isVerified: true
    }).limit(50);

    res.json({ success: true, shops });
  } catch (error) {
    next(error);
  }
};
