import Product from "../models/Product.js";

export const createProduct = async (req, res, next) => {
  try {
    const { name, brand, category, unit, description, image } = req.body;

    if (!name) {
      return res.status(400).json({ success: false, message: "Product name is required" });
    }

    const product = await Product.create({
      name,
      brand,
      category,
      unit,
      description,
      image
    });

    res.status(201).json({ success: true, product });
  } catch (error) {
    next(error);
  }
};

export const searchProducts = async (req, res, next) => {
  try {
    const q = (req.query.q || "").trim();

    if (!q) {
      const products = await Product.find().sort({ createdAt: -1 }).limit(30);
      return res.json({ success: true, products });
    }

    const products = await Product.find({
      $or: [
        { name: { $regex: q, $options: "i" } },
        { brand: { $regex: q, $options: "i" } },
        { category: { $regex: q, $options: "i" } }
      ]
    }).limit(50);

    res.json({ success: true, products });
  } catch (error) {
    next(error);
  }
};

export const getProduct = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ success: false, message: "Product not found" });
    res.json({ success: true, product });
  } catch (error) {
    next(error);
  }
};
