import express from "express";
import { createProduct, searchProducts, getProduct } from "../controllers/productController.js";
import { protect, allowRoles } from "../middleware/auth.js";

const router = express.Router();

router.get("/", searchProducts);
router.get("/:id", getProduct);
router.post("/", protect, allowRoles("shopkeeper", "admin"), createProduct);

export default router;
