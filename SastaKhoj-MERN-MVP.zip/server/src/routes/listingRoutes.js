import express from "express";
import {
  createListing,
  getMyListings,
  comparePrices,
  updateListing,
  deleteListing
} from "../controllers/listingController.js";
import { protect, allowRoles } from "../middleware/auth.js";

const router = express.Router();

router.get("/compare/:productId", comparePrices);
router.get("/mine", protect, allowRoles("shopkeeper"), getMyListings);
router.post("/", protect, allowRoles("shopkeeper"), createListing);
router.put("/:id", protect, allowRoles("shopkeeper"), updateListing);
router.delete("/:id", protect, allowRoles("shopkeeper"), deleteListing);

export default router;
