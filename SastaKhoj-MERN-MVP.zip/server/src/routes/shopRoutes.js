import express from "express";
import { createOrUpdateShop, getMyShop, getShop, nearbyShops } from "../controllers/shopController.js";
import { protect, allowRoles } from "../middleware/auth.js";

const router = express.Router();

router.get("/nearby", nearbyShops);
router.get("/:id", getShop);
router.get("/me/current", protect, allowRoles("shopkeeper"), getMyShop);
router.post("/", protect, allowRoles("shopkeeper"), createOrUpdateShop);

export default router;
