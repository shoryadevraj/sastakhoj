import mongoose from "mongoose";

const listingSchema = new mongoose.Schema(
  {
    product: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
    shop: { type: mongoose.Schema.Types.ObjectId, ref: "Shop", required: true },
    price: { type: Number, required: true, min: 0 },
    stockAvailable: { type: Boolean, default: true },
    quantity: { type: Number, default: 0, min: 0 }
  },
  { timestamps: true }
);

listingSchema.index({ product: 1, shop: 1 }, { unique: true });
listingSchema.index({ price: 1 });

export default mongoose.model("Listing", listingSchema);
