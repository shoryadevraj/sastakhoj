import mongoose from "mongoose";

const productSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    brand: { type: String, trim: true },
    category: { type: String, trim: true },
    unit: { type: String, trim: true },
    description: { type: String, trim: true },
    image: { type: String, trim: true }
  },
  { timestamps: true }
);

productSchema.index({ name: "text", brand: "text", category: "text" });

export default mongoose.model("Product", productSchema);
